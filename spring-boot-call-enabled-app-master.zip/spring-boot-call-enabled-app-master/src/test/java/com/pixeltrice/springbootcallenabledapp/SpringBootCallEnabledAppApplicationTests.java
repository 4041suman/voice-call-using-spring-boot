package com.pixeltrice.springbootcallenabledapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCallEnabledAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
